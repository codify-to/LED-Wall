Example of a generic exception handler
Author: Darren Wenn, Microchip Technology
Date: 15-Jan-2008

The main.c has a two possible exceptions that it may cause.
The exception.c file will handle all general exceptions and provides code to help
in analysing the source of the exception (exception cause and address).

